#!/usr/bin/env python3
# bench_worker.py
# one benchmark client process — runs puts or gets for N seconds and dumps results
# the launcher spawns these, don't run this directly

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import grpc

import objectstore_pb2 as pb
import objectstore_pb2_grpc as pb_grpc
FOUR_KB = b"x" * 4096


def make_stub(endpoint):
    return pb_grpc.ObjectStoreStub(grpc.insecure_channel(endpoint))


def run_puts(stub, duration, worker_id):
    key = f"bench{worker_id}"
    latencies = []
    deadline = time.monotonic() + duration
    ops = 0

    try:
        stub.Delete(pb.DeleteRequest(key=key))
    except grpc.RpcError:
        pass

    while time.monotonic() < deadline:
        t = time.monotonic()
        try:
            stub.Put(pb.PutRequest(key=key, value=FOUR_KB))
            latencies.append(time.monotonic() - t)
            ops += 1
        except grpc.RpcError:
            pass
        try:
            stub.Delete(pb.DeleteRequest(key=key))
        except grpc.RpcError:
            pass

    return ops, latencies


def run_gets(stub, duration, worker_id):
    key = f"bench{worker_id}"
    latencies = []
    deadline = time.monotonic() + duration
    ops = 0

    try:
        stub.Put(pb.PutRequest(key=key, value=FOUR_KB))
    except grpc.RpcError:
        try:
            stub.Update(pb.UpdateRequest(key=key, value=FOUR_KB))
        except grpc.RpcError:
            pass

    while time.monotonic() < deadline:
        t = time.monotonic()
        try:
            stub.Get(pb.GetRequest(key=key))
            latencies.append(time.monotonic() - t)
            ops += 1
        except grpc.RpcError:
            pass

    return ops, latencies


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cluster", required=True)
    parser.add_argument("--mode", required=True, choices=["put", "get"])
    parser.add_argument("--duration", type=int, default=30)
    parser.add_argument("--worker-id", type=int, default=0)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    endpoints = sorted(e.lower().strip() for e in args.cluster.split(","))

    if args.mode == "put":
        stub = make_stub(endpoints[0])
        ops, latencies = run_puts(stub, args.duration, args.worker_id)
    else:
        stub = make_stub(endpoints[args.worker_id % len(endpoints)])
        ops, latencies = run_gets(stub, args.duration, args.worker_id)

    lms = sorted(l * 1000 for l in latencies)

    with open(args.out, "w") as f:
        json.dump({"worker_id": args.worker_id, "mode": args.mode,
                   "ops": ops, "duration": args.duration, "latencies_ms": lms}, f)


if __name__ == "__main__":
    main()