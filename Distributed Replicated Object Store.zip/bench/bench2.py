#!/usr/bin/env python3
# bench2.py
# tests replication overhead — fixed 8 clients, put workload, 30s runs
# run once per config (1-node, 2-node, 3-node) and compare

import argparse
import json
import os
import subprocess
import sys
import tempfile

N = 8
DURATION = 30


def do_run(cluster, duration):
    procs, paths = [], []
    for i in range(N):
        f = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        f.close()
        paths.append(f.name)
        procs.append(subprocess.Popen([
            sys.executable, "bench/bench_worker.py",
            "--cluster", cluster, "--mode", "put",
            "--duration", str(duration), "--worker-id", str(i),
            "--out", f.name
        ]))

    for p in procs: p.wait()

    ops, lms = 0, []
    for path in paths:
        d = json.load(open(path))
        ops += d["ops"]
        lms += d["latencies_ms"]
        os.unlink(path)

    lms.sort()
    return ops / duration, (lms[int(len(lms) * 0.99)] if lms else 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--node1", required=True)
    ap.add_argument("--node2", default=None)
    ap.add_argument("--node3", default=None)
    ap.add_argument("--duration", type=int, default=DURATION)
    args = ap.parse_args()

    runs = [("1-node", args.node1)]
    if args.node2:
        runs.append(("2-node", f"{args.node1},{args.node2}"))
    if args.node2 and args.node3:
        runs.append(("3-node", f"{args.node1},{args.node2},{args.node3}"))

    print(f"bench2 | {N} clients | {args.duration}s | 4KiB objects\n")
    print(f"{'config':<10} {'ops/s':<12} {'p99ms':<12}")
    print("-" * 34)

    for label, cluster in runs:
        t, p99 = do_run(cluster, args.duration)
        print(f"{label:<10} {t:<12.1f} {p99:<12.2f}")


if __name__ == "__main__":
    main()