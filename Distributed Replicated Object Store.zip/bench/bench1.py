#!/usr/bin/env python3
# bench1.py
# runs put and get workloads at 1,2,4,8,16,32 concurrent clients
# prints ops/sec and p99 latency for each level

import argparse
import json
import os
import subprocess
import sys
import tempfile

DURATION = 30


def run(cluster, mode, n, duration):
    procs, paths = [], []
    for i in range(n):
        f = tempfile.NamedTemporaryFile(suffix=".json", delete=False)
        f.close()
        paths.append(f.name)
        procs.append(subprocess.Popen([
            sys.executable, "bench/bench_worker.py",
            "--cluster", cluster, "--mode", mode,
            "--duration", str(duration), "--worker-id", str(i),
            "--out", f.name,
        ]))

    for p in procs:
        p.wait()

    ops, lms = 0, []
    for path in paths:
        d = json.load(open(path))
        ops += d["ops"]
        lms += d["latencies_ms"]
        os.unlink(path)

    lms.sort()
    p99 = lms[int(len(lms) * 0.99)] if lms else 0
    return ops / duration, p99


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cluster", required=True)
    p.add_argument("--duration", type=int, default=DURATION)
    args = p.parse_args()

    print(f"cluster: {args.cluster}  duration: {args.duration}s  size: 4KiB\n")
    print(f"{'n':<6} {'put/s':<12} {'put_p99':<12} {'get/s':<12} {'get_p99':<12}")
    print("-" * 54)

    for n in [1, 2, 4, 8, 16, 32]:
        pt, pp = run(args.cluster, "put", n, args.duration)
        gt, gp = run(args.cluster, "get", n, args.duration)
        print(f"{n:<6} {pt:<12.1f} {pp:<12.2f} {gt:<12.1f} {gp:<12.2f}")


if __name__ == "__main__":
    main()